Run both commands 

1-roslaunch rob456_project rob456_project.launch


2-roslaunch nav_bundle nav_bundle.launch



then send the robot to a waypoint through rviz, sometimes when the robot stuck it will need to be manually moved
