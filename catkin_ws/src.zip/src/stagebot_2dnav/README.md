# stagebot_2dnav
move_base parameter folder for use with nav_bundle launch package
