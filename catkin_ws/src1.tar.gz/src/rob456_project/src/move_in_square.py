#!/usr/bin/env python
#import 
import roslib
import rospy
import math

#the geometry mesgs Twist msg
from geometry_msgs.msg import Twist

#the move base result messages
from move_base_msgs.msg import MoveBaseActionResult



def mb_callback(msg):
	#check if the robot reachers is goal
	if msg.status.status == 2 or msg.status.status ==4 or msg.status.status==5 or msg.status.status==6:
		print " Robot fileed to reaach the waypoint"
	elif msg.status.status==3:
		print"robot succefully reached the waypoint"

	#make new twist msg
	waypoint= Twist()

	#commnad waypoint 20 units to the right of the current posotion
	waypoint.linear.x=0.0
	waypoint.linear.y=-20.0
	waypoint.linear.z=0.0

	#commans the robot ot move 90 degree slockwise
	waypoint.angular.x=0.0
	waypoint.angular.y=0.0
	waypoint.angular.z=-90.0
	
	pub.publish(waypoint)

if __name__=="__main__":
	#initilize the node
	rospy.init_node('move_in_squre')

	#publis waypoint sata to robot
	pub= rospy.Publisher('/base_link_goal',Twist,queue_size=10)
	#pob= rospy.Publisher('/map_goal',Twist,queue_size=10)

	#subscriber to move base result
	sub=rospy.Subscriber('/move_base/result', MoveBaseActionResult,mb_callback)
	

	
	#turn controll
	rospy.spin()
